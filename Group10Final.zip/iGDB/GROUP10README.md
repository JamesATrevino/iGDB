# iGDB
iGDB iOS Final Release

Contributions:

Marcus Cruz: 33%
- UI polishes
- Fixes to Beta feedback

James Trevino: 33%
- Discuss

Jason Ngo: 33%
- Newsfeed

Differences:
- We did not allow users to add entries in our final release. This mirrors the structure of IMDB, and makes more sense given the audience for our app. We might implement that as time goes on, since it would be fairly easy, but it would really depend on the community of editors we gather.
- We had moved Reviews into our beta. It's in our final release.
- We did not add filters for the game list. It seemed unnecessary for our app since we have a search bar that works really well.


Sources:

http://stackoverflow.com/questions/446405/adjust-uilabel-height-depending-on-the-text
https://medium.com/@cwRichardKim/ios-xcode-tutorial-a-card-based-newsfeed-8bedeb7b8df7#.vw19ux40e