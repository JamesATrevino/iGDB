# iGDB
iGDB iOS Beta Release

Contributions:

Marcus Cruz: 35%
- Updated app visual design
- Implemented most of User Reviews / Rating feature

James Trevino: 30%
- Worked on setting up Discuss page

Jason Ngo: 35%
- Implemented entire search feature
- Bug fixes from Alpha
- Some of User Reviews / Ratings feature

Differences:
- We updated the visual look of the app to be cleaner.
- Rather than a 'rating feature' we upgraded to user Reviews.
- In our idea paper the search feature was SQL based, but based on feedback
  we changed it to be 'real' search.
- The Discuss tab was not in the beta release plan and is a work in progress.
- The 'View All My Reviews' was put into the Account Details tab.
